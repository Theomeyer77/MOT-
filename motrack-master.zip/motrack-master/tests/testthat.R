library(testthat)
library(motrack)

test_check("motrack")
