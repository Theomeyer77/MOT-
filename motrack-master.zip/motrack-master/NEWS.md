# motrack 0.3.0

# motrack 0.2.0

* Added trajectory simplification. You can generate trajectory with 100 frames per second and later remove datapoints, which can be interpolated.
* Updated versioning. From now, we will start to use more minor/patch numbering.

# motrack 0.1.0.9000

* Added a `NEWS.md` file to track changes to the package.
